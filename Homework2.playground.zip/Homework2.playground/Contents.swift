import UIKit

class Odev2 {
    func soru1(derece: Double) -> Double {
        let fahrenhiet = derece * 1.8 + 32
        return fahrenhiet
    }
    
    func soru2(kısaKenar: Int, uzunKenar: Int) -> Int {
        let cevre = (kısaKenar + uzunKenar) * 2
        return cevre
    }
    
    func soru3(sayi: Int) -> Int {
        if (sayi == 0) {
            return 1
        }
        var sonuc = 1
        for i in 1...sayi {
            sonuc = sonuc * i
        }
        return sonuc
    }
    
    func soru4(kelime: String, harf: Character) -> Int {
        var harfSayisi = 0
        for i in kelime {
            if i == harf {
                harfSayisi += 1
            }
        }
        return harfSayisi
    }
    
    func soru5(kenarSayisi: Int) -> Int {
        let icAcilarToplami = (kenarSayisi - 2) * 180
        return icAcilarToplami
    }
    
    func soru6(günSayisi: Int) -> Int  {
        var maasHesabi: Int
        var toplamMesaiSaati: Int
        let toplamCalismaSaati = günSayisi * 8
        if(toplamCalismaSaati > 160) {
            toplamMesaiSaati = toplamCalismaSaati - 160
            maasHesabi = (160 * 10) + (toplamMesaiSaati) * 20
        }
        else {
            maasHesabi = günSayisi * 10
        }
        return maasHesabi
    }

    func soru7(kotaMiktari: Int) -> Int {
        var toplamKotaUcreti: Int
        if (kotaMiktari <= 50) {
            toplamKotaUcreti = 100
        }
        else {
            toplamKotaUcreti = 100 + (kotaMiktari - 50)*4
        }
        return toplamKotaUcreti
    }
}

let o = Odev2()

let fahrenhietSonuc = o.soru1(derece: 35)
print("Fahrenhiet : \(fahrenhietSonuc) °F")

let dikdortgenCevresi = o.soru2(kısaKenar: 5, uzunKenar: 10)
print("Dikdörtgen çevre uzunluğu : \(dikdortgenCevresi)")

let faktoriyel = o.soru3(sayi: 6)
print("Faktoriyel işleminin sonucu : \(faktoriyel)")

let harf = o.soru4(kelime: "buse", harf:"e")
print("Kelimenin içindeki toplam harf sayısı: \(harf)")

let icAcilarToplamiSonuc = o.soru5(kenarSayisi: 5)
print("İç açılar toplamı : \(icAcilarToplamiSonuc)")

let toplamMaas = o.soru6(günSayisi: 14)
print("Toplam maaş: \(toplamMaas)₺")

let toplamKotaUcreti = o.soru7(kotaMiktari: 55)
print("Toplam kota ücreti : \(toplamKotaUcreti)₺")
